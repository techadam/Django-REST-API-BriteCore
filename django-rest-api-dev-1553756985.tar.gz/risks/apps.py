from django.apps import AppConfig


class RisksConfig(AppConfig):
    name = 'risks'
